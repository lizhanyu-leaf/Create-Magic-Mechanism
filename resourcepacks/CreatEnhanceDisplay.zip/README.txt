机械动力材质包，用以增强视觉体验
A Create related resourcepack of  enhancing visual experience

作者：多点触碰 Multitouches

本作品采用知识共享署名-非商业性使用 4.0 国际许可协议进行许可。
遵循以下协议： https://creativecommons.org/licenses/by-nc/4.0/deed.zh
转载务必附上作者及原贴，禁止商业用途的转载和发布

This work is licensed under the Creative Commons Attribution-NonCommercial 4.0 International License.  
Follow this agreement: https://creativecommons.org/licenses/by-nc/4.0/deed.zh  
When reposting, be sure to credit the author and the original post; commercial use is prohibited.

感谢Xe_Kr，cym提供部分模型、材质思路